<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    use HasFactory;

    protected $table = 'cliente';
    protected $primaryKey = 'NIFCliente';
    public $timestamps = false;
    protected $fillable = ['nombre', 'ciudad', 'telefono', 'email', 'estado'];
}
