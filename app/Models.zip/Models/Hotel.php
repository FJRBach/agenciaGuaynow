<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Hotel extends Model
{
    use HasFactory;

    protected $table = 'hotel';
    protected $primaryKey = 'IDHotel';
    public $timestamps = false;
    protected $fillable = ['nombre', 'numEstrellas', 'estado', 'ciudad'];

    public function regimenHospedaje()
{
    return $this->belongsTo(Regimen_hospedaje::class, 'IDRegimenHospedaje');
}

}
